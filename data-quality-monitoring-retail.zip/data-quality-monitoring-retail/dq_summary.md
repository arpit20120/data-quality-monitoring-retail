## 🔍 Data Quality Report – 2025-06-23 20:05:25

- ✅ Passed: **null_check** on `transaction_id` – 0 rows affected
- ✅ Passed: **null_check** on `date` – 0 rows affected
- ✅ Passed: **null_check** on `week` – 0 rows affected
- ✅ Passed: **null_check** on `month` – 0 rows affected
- ✅ Passed: **null_check** on `year` – 0 rows affected
- ✅ Passed: **null_check** on `store_id` – 0 rows affected
- ✅ Passed: **null_check** on `region` – 0 rows affected
- ✅ Passed: **null_check** on `store_manager` – 0 rows affected
- ✅ Passed: **null_check** on `product_id` – 0 rows affected
- ✅ Passed: **null_check** on `product_name` – 0 rows affected
- ✅ Passed: **null_check** on `category` – 0 rows affected
- ✅ Passed: **null_check** on `unit_cost` – 0 rows affected
- ✅ Passed: **null_check** on `units_sold` – 0 rows affected
- ✅ Passed: **null_check** on `revenue` – 0 rows affected
- ✅ Passed: **duplicate_check** on `transaction_id` – 0 rows affected
- ✅ Passed: **outlier_check** on `revenue` – 0 rows affected
- ✅ Passed: **outlier_check** on `unit_cost` – 0 rows affected
